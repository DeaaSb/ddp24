celcius = int(input("Masukkan suhu dalam Celcius: "))
fahrenheit = (celcius * 9/5) + 32

print(celcius, "derajat Celcius sama dengan", fahrenheit, "derajat Fahrenheit.")