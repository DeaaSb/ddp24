nama = "Dea Siti Badriah"
nim = "0110124008"
romble = "SI02"
no_telp = "085891781988"
alamat = "Bogor"

print ("nama saya", nama)
print ("nim saya", nim)
print ("no_telp saya", no_telp)
print ("alamat saya", alamat)