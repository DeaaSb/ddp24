nama = "Yeni"
nim = "0110124114"
romble = "SI02"
no_telp = "085719051322"
alamat = "Bogor"

print ("nama", nama)
print ("nim", nim)
print ("romble", romble)
print ("no_telp", no_telp)
print ("alamat", alamat)