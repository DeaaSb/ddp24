tb = int(input("masukan tinggi badan: "))
bb_ideal =(tb - 100) - ((tb - 100) * 0.15)
print ("jadi berat badan ideal saya adalah :", bb_ideal)