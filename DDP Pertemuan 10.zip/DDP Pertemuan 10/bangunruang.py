import math

def Kubus(sisi):
    luas = 6 * sisi **2
    print(f"luas kubus adalah = {luas}")

def balok(panjang, lebar, tinggi):
    luas= 2* panjang * lebar * tinggi
    print(f"luas balok adalah = {luas}")

def tabung(jari2, tinggi):
    luas= 2* 22/7 * jari2 * tinggi
    print(f"luas tabung adalah = {luas}")

def prisma(l_alas, kel_alas, tinggi):
    luas= 2 * l_alas * kel_alas * tinggi
    print(f"luas prisma adalah = {luas}")

def limas(l_alas, tinggi):
    luas = l_alas * tinggi
    print(f"luas limas adalah = {luas}")