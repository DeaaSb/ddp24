import operator
print()
print("## Penjumlahan ##")
operator.tambah(2,5)

print()
print("## Pengurangan ##")
operator.kurang(5,3)

print()
print("## Kali ##")
operator.kali(4,2)

print()
print("## Pembagian ##")
operator.bagi(12,3)

print()
print("## Pangkat ##")
operator.pangkat(2,2)


import bangundatar


print()
print("## Persegi ##")
bangundatar.l_Persegi(6)

print()
print("## Persegi ##")
bangundatar.l_persegipanjang(4,2)

print()
print("## Jajargenjang ##")
bangundatar.l_jajargenjang(15, 2)

print()
print("## Segitiga ##")
bangundatar.l_segitiga(2,6)

print()
print("## Lingkaran ##")
bangundatar.l_lingkaran(10)


import bangunruang

print()
print("## Kubus ##")
bangunruang.Kubus(5)

print()
print("## Balok ##")
bangunruang.balok(4, 5, 3)

print()
print("## Tabung ##")
bangunruang.tabung(7, 10)

print()
print("## Prisma ##")
bangunruang.prisma(2, 6, 3)

print()
print("## Limas ##")
bangunruang.limas(5, 5)