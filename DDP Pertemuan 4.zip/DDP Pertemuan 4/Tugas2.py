#Tugas 2

nilai = int(input("masukan nilai anda\n="))

if nilai >= 75 :
    print ("kamu dinyatakan lulus")
elif nilai <75 :
    print ("kamu dinyatakan tidak lulus")
else:
    print ("kamu ga jelas")

if nilai >=90 :
    print("dengan predikat A")
elif nilai >= 75:
    print ("dengan predikat B")
elif nilai >= 65 :
    print ("dengan predikat C")
elif nilai < 65 :
    print ("dengan predikat D")
else :
    print ("kamu tau")