#Tugas 4

status = (input("""Silahkan pilih status keanggotaan seperti dibawah ini
GOLD| SILVER| BRONZE
masukan pilihan anda
= """))

if status == "GOLD" or status== "SILVER":
    print ("Selamat kamu mendapatkan diskon!")
else :
    print ("Mohon maaf kamu tidak mendapatkan diskon")