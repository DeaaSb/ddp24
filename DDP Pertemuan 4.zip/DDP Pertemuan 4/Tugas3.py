#Tugas 3

usia = int(input("masukkan usia anda\n= "))

if usia >= 18:
    print("kamu sudah DEWASA")
elif usia >= 13:
    print("kamu saat ini sedang memasuki masa remaja")
else:
    print("kamu masih bocil")