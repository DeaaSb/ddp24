
#Tugas1

bilangan = int (input ("Masukan angka\n= "))

hasil = bilangan % 2
if hasil == 0 :
    print(f" Angka {bilangan} merupakan angka genap")
elif hasil == 1:
    print(f"Angka {bilangan} merupakan angka Ganjil")
else:
    print("angka ga jelas")