#Tugas 2

jumlah = 0
for i in range(1, 20, 2):
  jumlah += i
print(f"1 + 3 + 5 + 7 +9 +11 +13 + 15 +17 +19 = {jumlah}")