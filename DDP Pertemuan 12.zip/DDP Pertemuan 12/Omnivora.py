from Animal import Animal

class Omnivora(Animal):
    def __init__(self, nama, makanan, hidup, berkembang_biak, sistem_pencernaan, fleksibilitas_makanan):
        super().__init__(nama, makanan, hidup, berkembang_biak)
        self.sistem_pencernaan = sistem_pencernaan
        self.fleksibilitas_makanan = fleksibilitas_makanan
        
    def info_omnivora(self):
        super().info_animal()
        print("sistem pencernaan \t\t : ", self.sistem_pencernaan,
              "\nfleksibilitas makanan \t\t : ", self.fleksibilitas_makanan)
        
    
print("==objek 1==")       
omnnivora = Omnivora("Tikus", "Pemakan segala", "Darat", "melahirkan", "kompleks mencerna makanan", "sangat fleksibel")
omnnivora.info_omnivora()

print("==objek 2==")   
omnivora = Omnivora("Anjing", "Daging, tumbuhan, dsb", "Darat", "melahirkan", "sistem pencernaan yang relatif pendek", "fleksibel")
omnivora.info_omnivora()

print("==objek 3==")   
omnivora = Omnivora("Babi", "Sangat fleksibel", "Darat", "melahirkan", "kompleks mencerna makanan", "sangat fleksibel")
omnivora.info_omnivora()