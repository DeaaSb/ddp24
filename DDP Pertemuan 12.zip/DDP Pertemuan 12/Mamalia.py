from Animal import Animal

class Mamalia(Animal):
    def __init__(self, nama, makanan, hidup, berkembang_biak, ukuran_tubuh, jenis_kulit):
        super().__init__(nama, makanan, hidup, berkembang_biak)
        self.ukuran_tubuh = ukuran_tubuh
        self.jenis_kulit = jenis_kulit
        
    def info_mamalia(self):
        super().info_animal()
        print("ukuran_tubuh \t\t\t : ", self.ukuran_tubuh,
              "\njenis_kulit \t\t\t : ", self.jenis_kulit)
        
    
print("==objek 1==")       
mamalia = Mamalia("Kucing", "ikan", "Darat", "melahirkan", "kecil", "berbulu")
mamalia.info_mamalia()

print("==objek 2==")   
mamalia = Mamalia("Kuda", "rumput", "Darat", "melahirkan", "besar", "sedikit berbulu")
mamalia.info_mamalia()

print("==objek 3==")   
mamalia = Mamalia("Sapi", "rumput", "Darat", "melahirkan", "besar", "sedikit berbulu")
mamalia.info_mamalia()